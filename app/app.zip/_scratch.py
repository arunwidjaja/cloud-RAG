from imports import *

# Local Modules
from get_embedding_function import get_embedding_function
import config
import utils
import init_db
from utils import timer
import db_ops
import db_ops_utils
import doc_ops_utils
import doc_ops
import summarize
import time
import hashlib


def download_s3_folder(bucket_name, s3_folder, local_dir):
    """
    Downloads the contents of [s3_folder] in [bucket_name] to [local_dir].
    local_dir will be created if it does not exist.
    """
    try:
        # initialize connection with bucket, get list of files in folder
        s3 = boto3.client('s3')
        paginator = s3.get_paginator('list_objects_v2')
        pages = paginator.paginate(Bucket=bucket_name, Prefix=s3_folder)

        # create local directory if it doesn't exist
        if not os.path.exists(local_dir):
            os.makedirs(local_dir)

        # Iterate through files in folder and download them
        for page in pages:
            if 'Contents' in page:
                for obj in page['Contents']:
                    s3_key = obj['Key']
                    local_file_path = os.path.join(
                        local_dir, os.path.relpath(s3_key, s3_folder))

                    # Create directories if they don't exist
                    os.makedirs(os.path.dirname(
                        local_file_path), exist_ok=True)

                    # Download the file
                    print(f'Downloading {s3_key} to {local_file_path}')
                    s3.download_file(bucket_name, s3_key, local_file_path)
    except Exception as e:
        print(f"Error downloading from S3: {str(e)}")
        raise
    return True


def init_http_auth_db(embedding_function='openai') -> Chroma:
    try:
        print("Opening connection to the Chroma DB...")
        http_client = chromadb.HttpClient(
            host="localhost",
            port=config.PORT_DB,
            settings=Settings(
                chroma_client_auth_provider="chromadb.auth.basic_authn.BasicAuthClientProvider",
                chroma_client_auth_credentials="asdf:asdf"
            )
        )
    except Exception as e:
        print(
            f"An error occurred while initializing the Chroma HTTP Client: {str(e)}")

    # gets the path of the Chroma DB
    chroma_path = utils.get_env_paths()['DB']
    try:
        ef = get_embedding_function(embedding_function)
        print(f"Creating Chroma instance from: {chroma_path}")
        db = Chroma(client=http_client,
                    embedding_function=ef)

        file_list = utils.get_db_file_names(db, file_name_only=True)
        print(f"Files currently in database:\n{'\n'.join(file_list)}")
    except Exception as e:
        print(
            f"An error occurred while creating a Chroma instance: {str(e)}")
        raise
    return db


def create_htpasswd_file(username, password, filepath="server.htpasswd"):
    # Generate a salt and hash the password
    salt = bcrypt.gensalt()
    hashed_password = bcrypt.hashpw(password.encode(), salt).decode()

    # Format the line for the htpasswd file
    entry = f"{username}:{hashed_password}\n"

    # Write to .htpasswd file
    with open(filepath, "a") as file:
        file.write(entry)

    print(f"User {username} added to {filepath}.")


def init_db_old(embedding_function='openai') -> Chroma:
    embed_function = get_embedding_function(embedding_function)

    # detects the current environment and sets the persist directory
    chroma_path = utils.get_env_paths()['DB']
    data_path = utils.get_env_paths()['DOCS']

    # Initializes the chroma folder and data folder in temporary storage if running on AWS Lambda
    if 'tmp' in str(chroma_path):
        try:
            utils.copy_directory(
                config.PATH_CHROMA_LOCAL, chroma_path)
            utils.copy_directory(
                config.PATH_DOCUMENTS_LOCAL, data_path)
        except Exception as e:
            print(
                f"Error copying the Chroma DB to the temporary folder: {str(e)}")
            raise

    # Initializes the DB
    try:
        print(f"Initializing Chroma DB at: {chroma_path}")
        db = Chroma(persist_directory=str(chroma_path),
                    embedding_function=embed_function)
    except Exception as e:
        print(f"Error initializing Chroma: {str(e)}")
        raise
    return db


def main():
    db = init_db.init_db()
    print(db_ops_utils.get_all_collections_names(db))
    return


if __name__ == "__main__":
    main()
